package Final_Project.Alpha;

public abstract class Display_Parent
{
    boolean running = true;
    int choice;

    public abstract void Display();
    public abstract void check_Condition();

    public abstract void Start_Lines();
    public void End_Lines()
    {
        System.out.println("------------------------------------------------------------\n");
    }
}
