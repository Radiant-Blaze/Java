package Final_Project.Alpha;

public class Sales {
}
