package Final_Project.Alpha;

public class Stock extends Display_Parent
{

    @Override
    public void Display() {

    }

    @Override
    public void check_Condition() {

    }

    @Override
    public void Start_Lines() {

    }
}
