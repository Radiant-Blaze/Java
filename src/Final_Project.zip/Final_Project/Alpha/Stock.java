package Final_Project.Alpha;

public class Stock {
}
